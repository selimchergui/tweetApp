package fr.ecp.sio.superchat.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by mac on 22/01/15.
 */
public class FollowedUser{
    String handle;

    public void setHandle(String handle) {
        handle = handle;
    }

    public String getHandle() {
        return handle;
    }

}
